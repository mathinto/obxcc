<?php
session_start();
session_destroy();
echo "This is a test" . $_SESSION["cellphone"];
header("Location: index.html");

?>