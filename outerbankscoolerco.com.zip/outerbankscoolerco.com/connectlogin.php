<?php

session_start();

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
	header("location: landing.html");
	exit;
}

require_once "config.php";
$phone = $password = "";
$phone_error = $password_error = $login_error = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
			if(empty(trim($_POST["phone"]);
}

if(empty(trim($_POST["password"]))){
	$password_error = "Please enter your password.";
}
else{
	$password = trim($_POST["password"]);
}
if(empty($phone_error) && empty($password_error)){
	
	$sql = "SELECT phone, password FROM contactform WHERE phone = ?";
	
	if($stmt = mysqli_prepare($link, $sql)){
		mysqli_stmt_bind_param($stmt, "s", $param_phone);
		
		$param_phone = $phone;
		
		if(mysqli_stmt_execute($stmt)){
			mysqli_stmt_store_result($stmt);
			
			if(mysqli_stmt_num_rows($stmt) == 1){
				mysqli_stmt_bind_result($stmt, $phone,  $hashed_password);
				
				if(mysqli_stmt_fetch($stmt)){
					if(password_verify($password, $hashed_password))
{
	session_start();
		$_SESSION["loggedin"] = true;
		$_SESSION["phone"] = $phone;
		
		header("location: customerhome.html");
}
	$login_error = "Invalid phone number or password.";
		}
	}
}
else{
	$login_error = "Invalid phone or password.";
	}
}
	else{
		echo "Something went wrong. Please try again at another time.";
	}
	mysqli_stmt_close($stmt);
	}
}
mysqli_close($link);

?>
