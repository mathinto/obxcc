
<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
	die('Connection failed: ' . mysqli_error());
}
$cellphone = $_POST['cellphone'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$pwd = $_POST['pwd'];
$stadd = $_POST['stadd'];
$city = $_POST['city'];
$state = $_POST['state'];
$zipcode = $_POST['zipcode'];?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - Sign up</title>
<link href="custinfo.css" rel="stylesheet">
</head>

<body>

<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'index.html';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>

<main>

<h2>Contact Form</h2>

<div class="container">
	<form action="customerform.php" method="post">
	
		
		<label for="firstname"><b>First Name</b></label><br>
			<input type="text" placeholder="Enter First Name" name="firstname" required><br>

		<label for="lastname"><b>Last Name</b></label><br>
			<input type="text" placeholder="Enter Last Name" name="lastname" required><br>

		<label for="cellphone"><b>Phone Number</b></label><br>
			<input type="tel" placeholder="Enter Phone Number" name="cellphone" required><br>

		<label for="email"><b>Email</b></label><br>
			<input type="email" placeholder="Enter Email" name="email" required><br>
			
		<label for="pwd"><b>Password</b></label><br>
			<input type="password" placeholder="Enter Password" name="pwd" required><br>	
		
		<label for="conpassword"><b>Confirm Password</b></label><br>
			<input type="password" placeholder="Confirm Password" name="conpassword" required><br>
			
		
		<label for="stadd"><b>Home Address</b></label><br>
			<input type="text" placeholder="Enter Street Address" name="stadd" required><br>
		
		<div class="form-table">
		
		<div class="city-container">
		<label for="city"><b>City</b></label><br>
			<input type="text" placeholder="City" name="city" required><br>
		</div>
		
		<div class="state-container"><br>
		<label for="state"><b>State</b></label><br><br>
			
			<select name="state">
			  <option value="AL">Alabama</option>
			  <option value="AK">Alaska</option>
			  <option value="AZ">Arizona</option>
			  <option value="AR">Arkansas</option>
			  <option value="CA">California</option>
			  <option value="CO">Colorado</option>
			  <option value="CT">Connecticut</option>
			  <option value="DE">Delaware</option>
			  <option value="FL">Florida</option>
			  <option value="GA">Georgia</option>
			  <option value="HI">Hawaii</option>
			  <option value="ID">Idaho</option>
			  <option value="IL">Illinois</option>
			  <option value="IN">Indiana</option>
			  <option value="IA">Iowa</option>
			  <option value="KS">Kansas</option>
			  <option value="KY">Kentucky</option>
			  <option value="LA">Louisiana</option>
			  <option value="ME">Maine</option>
			  <option value="MD">Maryland</option>
			  <option value="MA">Massachusetts</option>
			  <option value="MI">Michigan</option>
			  <option value="MN">Minnesota</option>
			  <option value="MS">Mississippi</option>
			  <option value="MO">Missouri</option>
			  <option value="MT">Montana</option>
			  <option value="NE">Nebraska</option>
			  <option value="NV">Nevada</option>
			  <option value="NH">New Hampshire</option>
			  <option value="NJ">New Jersey</option>
			  <option value="NM">New Mexico</option>
			  <option value="NY">New York</option>
			  <option value="NC">North Carolina</option>
			  <option value="ND">North Dakota</option>
			  <option value="OH">Ohio</option>
			  <option value="OK">Oklahoma</option>
			  <option value="OR">Oregon</option>
			  <option value="PA">Pennsylvania</option>
			  <option value="RI">Rhode Island</option>
			  <option value="SC">South Carolina</option>
			  <option value="SD">South Dakota</option>
			  <option value="TN">Tennessee</option>
			  <option value="TX">Texas</option>
			  <option value="UT">Utah</option>
			  <option value="VT">Vermont</option>
			  <option value="VA">Virginia</option>
			  <option value="WA">Washington</option>
			  <option value="WV">West Virginia</option>
			  <option value="WI">Wisconsin</option>
			  <option value="WY">Wyoming</option>
			</select>
			</div>
			</div>
			<br>
		<label for="zip"><b>Zip Code</b></label>
			<input type="text" placeholder="Zip Code" name="zipcode" maxlength="5" required><br>
		
		<div class="button-container">
		<div class="cancel-conatiner">
		<button type="reset" class="cancel-button">Clear</button>
		</div>
		<div class="submit-container">
		<input type="submit" class="submit-button" name="submit" value="Submit"/>
		</div>
		</div>


</form>
</div>
<?php


if ($_REQUEST['submit'] == "Submit"){
$sql = "INSERT INTO `contactform` (`cellphone`, `firstname`, `lastname`, `email`, `password`) VALUES ('$cellphone', '$firstname', '$lastname', '$email', '$pwd')";
$result = mysqli_query($conn, $sql);

$sql = "INSERT INTO `homeadd` (`stadd`, `city`, `state`, `zipcode`, `contactform_cellphone`) VALUES ('$stadd', '$city', '$state', '$zipcode','$cellphone')";
$result = mysqli_query($conn, $sql);


	$_SESSION['cellphone'] = $cellphone;
	header("Location: customerhome.php");
}
mysql_close($conn); 	

?>

</main>
<br>
</body>
</html>

















