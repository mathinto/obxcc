<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$cardname = $_POST['cardname'];
$cardnumber = $_POST['cardnumber'];
$expmonth = $_POST['expmonth'];
$expyear = $_POST['expyear'];
$cvv = $_POST['cvv'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - Chceckout</title>
<link href="checkout.css" rel="stylesheet">
</head>

<body>

<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'customerhome.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>

<main>
<div class="page-divide">


<form method="post">
<div class="left-column">
<h3>Cart</h3>

<div class="checkout-divide">

<?php
$total = 0;
$sql = "SELECT `icequantity`, `icetype` FROM cooler WHERE order_ordernum = " . $_SESSION['ordernum']. " AND order_contactform_cellphone = " . $_SESSION['cellphone'];
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$icequantity = $row['icequantity'];
$icetype = $row['icetype'];

echo "<h4><u>Ice Selection</u></h4>";
echo $icequantity, " - ", $icetype, "<br><br>Ice: $", $icequantity * 50, "<br>";
$total += $icequantity * 50;
$sql = "SELECT `bev1`, `bev2`, `bev3` FROM bevselect WHERE cooler_order_ordernum = " . $_SESSION['ordernum']. " AND cooler_order_contactform_cellphone = " . $_SESSION['cellphone'];
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$bev1 = $row['bev1'];
$bev2 = $row['bev2'];
$bev3 = $row['bev3'];

echo "<h4><u>Drink Selection</u></h4>";

echo $bev1, " - 6", "<br><br>", $bev2, " - 6", "<br><br>", $bev3, " - 6";
echo "<br><br>Drinks: ", "$150";
$total += 150;



echo "<br><br><b><u>Grand Total: </b>", "$", $total, "</u>";

?>



</div>


<br>
<div class="left-butt">
<button class="back-button" onclick="window.location.href = 'drink.php'";>Back</button>
</div>

</div>
<div class="right-column">
<h3>Payment</h3>
	<label for="cardname">Name on Card</label><br>
	<input type="text" id="cname" name="cardname" placeholder="John Doe" required><br>
	<label for="ccnum">Credit card number</label>
	<input type="text" id="ccnum" name="cardnumber" placeholder="****-****-****-1234" required><br>
	<label for="expmonth">Exp Month</label><br>
	<input type="text" id="expmonth" name="expmonth" placeholder="05" required><br>
	<label for="expyear">Exp Year</label>
	<input type="text" id="expyear" name="expyear" placeholder="2021" required><br>	
	<label for="cvv">CVV</label><br>
	<input type="text" id="cvv" name="cvv" placeholder="987" required>
	  <div class="right-butt">
	<button type="submit" class="submit-button" name='submit' value='Submit' >Submit my Order</button>
	</div>	
</div>
	
</form>
</div>

<?php
if ($_REQUEST['submit'] == "Submit"){
$sql = "INSERT INTO `checkout`(`cardname`, `cardnumber`, `expmonth`, `expyear`, `cvv`, `cooler_order_ordernum`, `cooler_order_contactform_cellphone`) VALUES ('$cardname', '$cardnumber', '$expmonth', '$expyear', '$cvv', " . $_SESSION['ordernum'] . ", " . $_SESSION['cellphone'] . ")";
$result = $conn->query($sql);


$sql = "SELECT firstname, email from contactform WHERE cellphone = " . $_SESSION['cellphone'];
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$email = $row['email'];
$firstname = $row['firstname'];
	
$to      = $email;
$subject = 'Order Confirmation';
$message = 'Hello '. $firstname . ", our team at Outer Banks Cooler Co. would like to thank you for your support.";
$headers = 'From: matthew.hinton.17@cnu.edu' . "\r\n" .
    'Reply-To: matthew.hinton.17@cnu.edu' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);

header("Location: thankyou.php");
	}
	
mysql_close($conn); 
?>
</main>
<br>
<footer>Copyright &copy; 2022 Outer Banks Cooler Co.</footer>
</body>
</html>
