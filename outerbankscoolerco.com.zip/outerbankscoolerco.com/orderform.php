<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
	die("Connection failed: " . mysqli_error());
}

$startdate = $_POST['startdate'];
$enddate = $_POST['enddate'];

?>
<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - Order Form</title>
<link href="custinfo.css" rel="stylesheet">
</head>

<body>

<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'customerhome.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>

<main>

<h2>Just Tell Us When...</h2>

<div class="container">
	<form action="orderform.php" method="post">
	
		<div class="form-table">
		
		<div class="city-container">
		<label for="startdate"><b>Start Date</b></label><br><br>
		<?php
echo "<input type = 'date' name = 'startdate' value = '". date("Y-m-d"). "' required>";
?>
		</div>
		
		<div class="state-container">
			<label for="enddate"><b>End Date</b></label><br><br>
		<input type="date"  name="enddate" required>
			
			</div>
			</div>

		<div class="button-container">
		<div class="cancel-conatiner">
		<button type="reset" class="cancel-button">Clear</button>
		</div>
		<div class="submit-container\">
		<input type="submit" class="submit-button" value="Submit" name='submit'/>
		</div>
		</div>
	</form>
</div>

<?php

$sql = "INSERT INTO `order` (`ordernum`, `startdate`, `enddate`, `contactform_cellphone`, `deliverystatus`) VALUES (NULL, '$startdate', '$enddate'," . $_SESSION['cellphone'] . ", 0)";
$result = mysqli_query($conn, $sql);


if ($_REQUEST['submit'] == "Submit"){
	$_SESSION['startdate'] = $startdate;
	$_SESSION['enddate'] = $enddate;
	header("Location: deliveryform.php");
	}
	


mysql_close($conn);
?>
		
	




</main>
<br>


<footer>Copyright &copy; 2022 Outer Banks Cooler Co.</footer>

</body>
</html>
