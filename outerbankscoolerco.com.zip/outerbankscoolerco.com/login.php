<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
	die('Connection failed: ' . mysqli_error());
} 

$cellphone = trim($_POST['cellphone']);
$pwd = trim($_POST['pwd']);

$sql = "SELECT cellphone, password FROM contactform WHERE cellphone = '$cellphone'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$count = mysqli_num_rows($result);
if ($_REQUEST['submit'] == "Submit"){
	
	if ($count == 1){
		
		$_SESSION['cellphone'] = $cellphone;		
		if ($cellphone != "2521234567"){ 
					header("Location: customerhome.php");
		}
		else{
			header("Location: employeedelivery.php");
		}
	}
	else{
		echo "Invalid phone number or password.";
}}


mysqli_close($conn);


?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - Login</title>
<link href="cooler.css" rel="stylesheet">
</head>
<body>
<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'index.html';" class="home-icon">
</nav>
<main>
<h2>Outer Banks Cooler Co. Login</h2>

<div class="login-form-container">
<img src="images/relax.jpg" alt="relax" class="login-image">

<br>
<div>

</div>

<form action="login.php" method="post">

	<div class="login-form-container-a">
	<label for="cusid"><b>Phone Number:</b></label>
	</div>
	<br>
	<div class="login-form-container-b">
	<input type="text" placeholder="Enter Phone Number" id="phone" name="cellphone" class="form-control " required>
	
	</div>
	<br>
	
	<div class="login-form-container-a">
	<label for="pwd"><b>Password:</b></label>
	</div>
	<br>
	<div class="login-form-container-b">
	<input type="password" placeholder="Enter Password" id="pwd" ] name="pwd" class="form-control"  required>
	  
	</div>
	
	
	<br>
	<button type="reset" class="cancel-button">Cancel</button>
	
	<input type="submit" class="submit-button" value="Submit" name='submit'/>
	<br>
	<div class="login-form-container-a">
	<label>
      <input type="checkbox" checked="checked" name="remember-me">Remember me
    </label>
	</div>

	</form>
</div>
 
</main>
<br>
<footer>Copyright &copy; 2022 Outer Banks Cooler Co.</footer>
</body>
</html>