<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$bev1 = $_POST['bev1'];
$bev2 = $_POST['bev2'];
$bev3 = $_POST['bev3'];

?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - Order</title>
<link href="order.css" rel="stylesheet">
</head>

<body>

<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'customerhome.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>
<h2>Let us stock the cooler!</h2>
<main>

<form method="post">
	<div class="big-drink-container">
		<div class="drink-container">
		<img class="drink-img" src="images/voss.png">
		<img class="drink-img" src="images/aquafina.png">
		<img class="drink-img" src="images/gatorade.png">
		<img class="drink-img" src="images/pureleaf.png">
		</div>	
		<div class="drink-container">
		<img class="drink-img" src="images/oceanspray.png">
		<img class="drink-img" src="images/bubly.png">
		<img class="drink-img" src="images/sierramist.png">
		<img class="drink-img" src="images/pepsi.png">

		</div>	
		
		<blockquote>Each beverage selected will be devilvered in quantities of 6.</blockquote>
		<br>
		
		<select class="bev-select" name="bev1" >
			<option value="-">- Select One -</option>
			  <option value="AQFA">Aquafina</option>
			  <option value="BBLY">Bubly</option>
			  <option value="DDRPP">Diet Dr. Pepper</option>
			  <option value="DMTDW">Diet MTN Dew</option>
			  <option value="DPPSI">Diet Pepsi</option>
			  <option value="DRPP">Dr. Pepper</option>
			  <option value="GTAD">Gatorade</option>
			  <option value="MTDW">MTN Dew</option>
			  <option value="OCSP">Ocean Spray</option>
			  <option value="PPSI">Pepsi</option>
			  <option value="PRLF">Pure Leaf</option>
			  <option value="SMST">Sierra Mist</option>
			  <option value="VOSS">Voss</option>
			</select>
		<br>
		<br>
		<select class="bev-select" name="bev2" >
			<option value="-">- Select One -</option>
			  <option value="AQFA">Aquafina</option>
			  <option value="BBLY">Bubly</option>
			  <option value="DDRPP">Diet Dr. Pepper</option>
			  <option value="DMTDW">Diet MTN Dew</option>
			  <option value="DPPSI">Diet Pepsi</option>
			  <option value="DRPP">Dr. Pepper</option>
			  <option value="GTAD">Gatorade</option>
			  <option value="MTDW">MTN Dew</option>
			  <option value="OCSP">Ocean Spray</option>
			  <option value="PPSI">Pepsi</option>
			  <option value="PRLF">Pure Leaf</option>
			  <option value="SMST">Sierra Mist</option>
			  <option value="VOSS">Voss</option>
			</select>
			<br>
			<br>
		<select class="bev-select" name="bev3" >
			<option value="-">- Select One -</option>
			  <option value="AQFA">Aquafina</option>
			  <option value="BBLY">Bubly</option>
			  <option value="DDRPP">Diet Dr. Pepper</option>
			  <option value="DMTDW">Diet MTN Dew</option>
			  <option value="DPPSI">Diet Pepsi</option>
			  <option value="DRPP">Dr. Pepper</option>
			  <option value="GTAD">Gatorade</option>
			  <option value="MTDW">MTN Dew</option>
			  <option value="OCSP">Ocean Spray</option>
			  <option value="PPSI">Pepsi</option>
			  <option value="PRLF">Pure Leaf</option>
			  <option value="SMST">Sierra Mist</option>
			  <option value="VOSS">Voss</option>
			</select>
		
		<br>
		<div class="button-container">
		<div class="back-container">
			<button class="back-button" onclick="window.location.href = 'iceorder.php'";>Back</button>
			</div>
			</div>
		
		
		<div class="button-container">
			
			<div class="submit-container">
			<input type="submit" class="submit-button" value="Submit" name='submit' onclick="window.location.href='checkout.php'"/>
			</div>
			</div>
	</div>
</form>
<?php


if ($_REQUEST['submit'] == "Submit"){
$sql = "INSERT INTO `bevselect` (`bev1`, `bev2`, `bev3`, `cooler_order_ordernum`, `cooler_order_contactform_cellphone`) VALUES ('$bev1', '$bev2', '$bev3', " . $_SESSION["ordernum"] . ", " . $_SESSION['cellphone'] . ")";
$result = $conn->query($sql);

header("Location: checkout.php");
	}
	
mysql_close($conn); 
?>

</main>
<br>
<footer>Copyright &copy; 2022 Outer Banks Cooler Co.</footer>
</body>
</html>
