<?php
session_start();
if (!isset($_SESSION['cellphone'])) {
	header("Location: index.html");
}
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
	die("Connection failed: " . mysqli_error());
}

$stradd = $_POST['stradd'];
$town = $_POST['town'];
$milepost = $_POST['milepost'];
$housename = $_POST['housename'];
$sql = "SELECT `ordernum` FROM `order` WHERE startdate = '". $_SESSION['startdate'] . "' AND enddate = '" . $_SESSION['enddate'] . "' AND contactform_cellphone = " . $_SESSION['cellphone'];
$result = mysqli_query($conn, $sql);
$row = $result->fetch_assoc();
$ordernumber = $row['ordernum'];
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - Order Form</title>
<link href="custinfo.css" rel="stylesheet">
</head>

<body>

<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'customerhome.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>

<main>

<h2>... And Where</h2>

<div class="container">
	<form action="deliveryform.php" method="post">
	
		
		<label for="stradd"><b>Delivery Address</b></label><br>
			<input type="text" placeholder="Enter Delivery Address" name="stradd" required><br>
		
		<div class="form-table">
		
		<div class="city-container">
		<label for="town"><b>Town</b></label><br><br>
		<select name="town">
			<option value="-">-Select One-</option>
			  <option value="KH">Kitty Hawk</option>
			  <option value="KD">Kill Devil Hills</option>
			  <option value="NH">Nags Head</option>
			</select>
		</div>
		
		<div class="state-container">
			<label for="milepost"><b>Milepost</b></label>
			<input type="text" placeholder="Milepost" name="milepost" required><br>
			
			</div>
			</div>

		
		<label for="housename"><b>House Name</b></label><br>
			<input type="text" placeholder="House Name" name="housename"><br>


		<div class="button-container">
		<div class="cancel-conatiner">
		<button type="reset" class="cancel-button">Clear</button>
		</div>
		<div class="submit-container\">
		<input type="submit" class="submit-button" value="Submit" name='submit'/>
		</div>
		</div>

	
	</form>
</div>

<?php



$sql = "INSERT INTO `deladd`(`stradd`, `town`, `milepost`, `housename`, `order_ordernum`, `order_contactform_cellphone`) VALUES ('$stradd', '$town', '$milepost', '$housename', '$ordernumber', " . $_SESSION['cellphone'] . ")";
$result = mysqli_query($conn, $sql);

	
if ($_REQUEST['submit'] == "Submit"){
	$_SESSION['ordernum'] = $ordernumber;
	header("Location: iceorder.php");
	}
	

mysql_close($conn);
?>
		


</main>
<br>


<footer>Copyright &copy; 2022 Outer Banks Cooler Co.</footer>

</body>
</html>
