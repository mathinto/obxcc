<?php
session_start();
if (!isset($_SESSION['cellphone'])) {
	header("Location: login.php");
}
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
	die("Connection failed: " . mysqli_error());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - Employee Delivery</title>
<link href="cooler.css" rel="stylesheet">
</head>
<body>

<main>
<nav>
<img src="images/book.png" alt="custinfo" onclick="window.location.href='employee_customer_view.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>
<h2>Active Delivery</h2>


<?php

$sql = "SELECT o.ordernum, c.lastname, d.stradd, d.town, d.milepost, r.icequantity, r.icetype, b.bev1, b.bev2, b.bev3, o.deliverystatus
		 FROM cooler.order o, cooler.contactform c, cooler.deladd d, cooler.cooler r, cooler.bevselect b
		 WHERE o.contactform_cellphone = c.cellphone AND o.contactform_cellphone = d.order_contactform_cellphone 
		 AND o.contactform_cellphone = b.cooler_order_contactform_cellphone AND o.ordernum = r.order_ordernum AND o.ordernum = b.cooler_order_ordernum AND o.ordernum = d.order_ordernum ";

$result = $conn->query($sql);
$row = $result->fetch_assoc();


	echo "<table>
			<tr>
				<th>Order Number</th>
				<th>Last Name</th>
				<th>Delivery Address</th>
				<th>Town</th>
				<th>Milepost</th>
				<th>Ice Quantity</th>
				<th>Ice Type</th>
				<th>Beverage 1</th>
				<th>Beverage 2</th>
				<th>Beverage 3</th>
				<th>Delivered</th>
			</tr>	";

	while($row = $result->fetch_assoc()){	
	echo "<tr><td>".$row['ordernum']."</td><td>".$row['lastname']."</td><td>".$row['stradd']."</td><td>".$row['town']."</td><td>".$row['milepost']."</td><td>".$row['icequantity']."</td><td>".$row['icetype']."</td><td>".$row['bev1']."</td><td>".$row['bev2']."</td><td>".$row['bev3']."</td>"; 
	
	
if ($row['deliverystatus'] != 0){
	echo	"<td><input name=\"deliverycheck\" type=\"checkbox\" checked></td>"; 
} else{
	echo	"<td><input name=\"deliverycheck\" name='checkbox' value='1' type=\"checkbox\"></td>"; 
}
	echo	"</tr>";  
	}	
	echo "</table>";

	#echo "<br><input type=\"submit\" class=\"submit-button\" value=\"Update\" name='update'/>";


if($_REQUEST['checkbox'] == "1"){
$sql = "UPDATE order SET deliverystatus = 1 WHERE contactform_cellphone = cellphone AND ordernum = order_ordernum";
$result = $conn->query($sql);
}
mysql_close($conn); 
?>


	


</main>
<br>
<footer>Copyright Outer Banks Cooler Co. &copy; 2022 </footer>

</body>
</html>
