<?php
session_start();
?>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - View Customer Information</title>
<link href="cooler.css" rel="stylesheet">
</head>
<body>

<main>

<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'customerhome.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>
	<div class="cushome-img1-text"></div>
						
<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT firstname FROM contactform WHERE cellphone =" . $_SESSION['cellphone'];
$result = $conn->query($sql);
echo "<h1>
		Welcome to the good life ";

while($row = $result->fetch_assoc()){
echo $row['firstname'] ; 
}

echo "!</h1>";
$sql = "SELECT o.ordernum, o.startdate, o.enddate
		 FROM cooler.order o, cooler.contactform c
		 WHERE o.contactform_cellphone = c.cellphone AND c.cellphone = " . $_SESSION['cellphone'];
$result = $conn->query($sql);
if ($result->num_rows > 0) {
echo "<table>
			<tr>
				<td>Order Number</td>
				<td>Start Date</td>
				<td>End Date</td>
			</tr>	";
while($row = $result->fetch_assoc()){
	
	echo "<tr>";
	echo	"<td>".$row['ordernum']."</td>";
	echo	"<td>".$row['startdate']."</td>"; 
	echo	"<td>".$row['enddate']."</td>";
	echo	"</tr>";  //$row['index'] the index here is a field name
	
	
}
echo "</table>";
}

else {
	echo "<table>
			<tr>
				<th>Order Number</th>
				<th>Start Date</th>
				<th>End Date</th>
			</tr>	";

	echo "<tr><td> - </td><td> - </td><td> - </td></tr>";  //$row['index'] the index here is a field name
	
	echo "</table>";
}


echo "<br><div class=\"cushome-img1\"></div>";

echo "<br><div class=\"sign-up-button-holder\">
		<button class=\"sign-up-button\" onclick=\"window.location.href = 'orderform.php';\">Schedule Your Delivery</button>
		
		</div>
		<br>
";

mysql_close(); 

?>

	
	

<div class="cushome-img1"></div>

<br>

	
<br>
<h3>My Orders</h3>


</main>
<br>
<footer>Copyright Outer Banks Cooler Co. &copy; 2022 </footer>
<br>
</body>
</html>
