<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = new mysqli($servername, $username, $password, $dbname);
if (!$conn) {
	die("Connection failed: " . mysqli_error());
}

$looseice = $_POST['looseice'];
$baggedice = $_POST['baggedice'];
$icetype = '';
$icequantity = $_POST['icequantity'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co. - Order</title>
<link href="order.css" rel="stylesheet">
</head>

<body>

<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'customerhome.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>
<h2>Select Ice</h2>
<main>

<form method="post">
<div class="container-2">
	<div class="container">
	
		<div class="ice-type-container-a">
			<img src="images/baggedice.jpg" alt="baggad-ice" class="ice">
			<br>
			<label for="baggedice"><b>20 lbs. Bagged</b></label>
			<input type="checkbox" value="B" name="baggedice">
		</div>	
		
		
		<div class="ice-type-container-b">
			<img src="images/looseice.jpg" alt="baggad-ice" class="ice">
			<br>
			<label for="looseice"><b>20 lbs. Loose</b></label>
			<input type="checkbox" value="L" name="looseice">
		</div>	
		
	</div>
	
	<div class="ice-quantity">
		<select name="icequantity" required>
				<option value="-">- Choose Quantity -</option>
				  <option value="1">1</option>
				  <option value="2">2</option>
				  <option value="3">3</option>
				  <option value="4">4</option>
				  <option value="5">5</option>
				  <option value="6">6</option>
				  <option value="7">7</option>
				  <option value="8">8</option>
		</select>
	</div>
	
	<br>
	
	<div class="button-container">
		<div class="back-container">
		<button class="back-button" onclick="window.location.href='deliveryform.php'">Back</button>
		</div>
		</div>
	
	
	<div class="button-container">
		<div class="submit-container">
		<input type="submit" class="submit-button" value='Submit' name='submit' onclick="window.location.href='drink.php'">
		</div>
		</div>
</div>

</form>

<?php

if (empty($baggedice)){
	$icetype = $looseice;
}
if (empty($looseice)){
	$icetype = $baggedice;
}



$sql = "INSERT INTO `cooler` (`icequantity`, `icetype`, `order_ordernum`, `order_contactform_cellphone`) VALUES ('$icequantity', '$icetype', " . $_SESSION["ordernum"]. ", " . $_SESSION['cellphone'] . ")";
$result = $conn->query($sql);
if ($_REQUEST['submit'] == "Submit"){

header("Location: drink.php");	
	}
mysqli_close($conn);
	

?>
</main>
<br>
<footer>Copyright &copy; 2022 Outer Banks Cooler Co.</footer>
</body>
</html>
