<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co.</title>
<link href="checkout.css" rel="stylesheet">
</head>
<body>

<nav>
<img src="images/home.png" alt="home" onclick="window.location.href = 'customerhome.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>
<main>
<div class="thankyou-container">
<h2>Thank you for your order!</h2>
<div class="thankyou-text">
<blockquote style='padding: 1em;'>We appreciate you choosing Outer Banks Cooler Co. to satisfy your summer needs for ice and cold drinks. <br><br><br>
We encourage all customers to like and share our social media pages <b>@outerbankscoolerco.</b></blockquote>

<ul class="no-bullets">
<li><img src="images/socialmedia.png" class="list-image" alt="social" width='30%'></li>
</ul><br>

<blockquote>
Below, you will find some our favorite activities to do while in the Outer Banks. We hope your family will enjoy them <br>as much as ours.</b> <br><br>
</blockquote>
</div>

<ul class="no-bullets">
	<li><img src="images/act1.png" class="list-image" alt="lighthouses"></li>
	<li><img src="images/act2.png" class="list-image" alt="wildhorses"></li>
	<li><img src="images/act3.png" class="list-image" alt="duck"></li>
	<li><img src="images/act4.png" class="list-image" alt="fishing"></li>
	<li><img src="images/act5.png" class="list-image" alt="jetski"></li>
</ul>
<div class="thankyou-text">
<blockquote style="text-align: center;">Want to find more great activities?<br><br>
Visit our friends at Shoreline Vacation Rentals to see everything the Outer Banks has to offer.<br><br>
https://shorelineobx.com/things-to-do-in-outer-banks-nc-attractions/</blockquote>
</div>
</div>

<table class="activity-table">
<tr>
<th></th>
<th></th>
<th></th>
</tr>

<tr>
<th></th>
<th></th>
<th></th>
</tr>
</table>
<br>


</main>
<br>
</body>
</html>