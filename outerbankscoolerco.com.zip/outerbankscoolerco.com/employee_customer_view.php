<?php
session_start();
if ($_SESSION['cellphone'] != '2521234567') {
	header("Location: login.php");
}
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "cooler";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
	die("Connection failed: " . mysql_error());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Outer Banks Cooler Co.</title>
<link href="cooler.css" rel="stylesheet">
</head>
<body>

<main>
<nav>
<img src="images/car.png" alt="activedel" onclick="window.location.href='employeedelivery.php';" class="home-icon">
<img src="images/logout.png" alt="logout" onclick="window.location.href='logout.php';" class="home-icon">
</nav>

<?php
$sql = "SELECT cellphone, firstname, lastname, email FROM contactform ORDER BY lastname";
$result = $conn->query($sql);


	echo "<h1><center>Customer Contact Info</center></h1>";

	echo "<table>
			<tr>
				<th>Cell Phone</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
			</tr>	";
while($row = $result->fetch_assoc()){

	echo "<tr>";
	echo 	"<td>".$row['cellphone']."</td>" ; 
	echo 	"<td>".$row['firstname']."</td>"  ;
	echo 	"<td>".$row['lastname']."</td>" ;
	echo 	"<td>".$row['email']."</td>" ;
	echo 	"</tr>";  //$row['index'] the index here is a field name
	}
	echo "</table>";



mysql_close(); 
?>


	


</main>
<br>
<footer>Copyright Outer Banks Cooler Co. &copy; 2022 </footer>

</body>
</html>
